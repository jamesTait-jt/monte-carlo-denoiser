#include "Property.hpp"

namespace Tungsten {

Property::~Property()
{
}

}
